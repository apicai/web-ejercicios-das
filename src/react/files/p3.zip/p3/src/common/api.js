// Código que llama a nuestra API en el servidor fake

export function login(email, password) {
  const body = JSON.stringify({email, password});
  return delay().then(() => fetch('/api/users/login', {method: 'post', body}));
}
export function logout() {
  return delay().then(() => fetch('/api/users/logout', {method: 'delete'}));
}
export function registro(data) {
  const body = JSON.stringify(data);
  return delay().then(() => fetch('/api/users', {method: 'post', body}));
}
export function perfil() {
  return delay().then(() => fetch('/api/users/me'));
}
export function actPerfil(data) {
  const body = JSON.stringify(data);
  return delay().then(() => fetch('/api/users/me', {method: 'put', body}));
}
export function baja() {
  return delay().then(() => fetch('/api/users/me', {method: 'delete'}));
}

function delay(delay) {
  return new Promise(resolve => setTimeout(() => {
    resolve();
  }, delay || 500));
}