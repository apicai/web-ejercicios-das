from django.contrib import admin
from django.urls import path
from api.users import views
from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView

# Ejercicios 13, 16, 18, 19
urlpatterns = [

    path('admin/', admin.site.urls),
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/schema/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
]
