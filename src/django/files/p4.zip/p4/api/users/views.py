from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.db.utils import IntegrityError
from django.core.exceptions import ObjectDoesNotExist
from api.users import serializers
from drf_spectacular.utils import extend_schema, OpenApiResponse


class RegistroView(generics.CreateAPIView):
    # Ejercicio 13 y 15
    pass


class LoginView(generics.CreateAPIView):
    # Ejercicio 16
    pass



class UsuarioView(generics.RetrieveUpdateDestroyAPIView):
    # Ejercicio 18 y 20
    pass



# Ejercicio 26
class LogoutView(generics.DestroyAPIView):
    # Ejercicio 19
    pass