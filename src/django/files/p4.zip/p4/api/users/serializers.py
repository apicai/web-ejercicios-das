import re
from rest_framework import serializers, exceptions
from django.contrib.auth import authenticate
from api.users import models

class UsuarioSerializer(serializers.ModelSerializer):

    class Meta:
        # Ejercicio 5 y 22
        pass

    def validate_password(self, value):
        # Ejercicio 7: completar
        valid_password = True
        if valid_password:
            return value
        else:
            raise exceptions.ValidationError('Invalid password format')

# Ejercicio 8
#    def create(self, validated_data):
#       return models.Usuario.objects.create_user(username=validated_data['email'], **validated_data)

#    def update(self, instance, validated_data):
#        if (validated_data.get('password')):
#            instance.set_password(validated_data.pop('password'))
#        return super().update(instance, validated_data)
    
class LoginSerializer(serializers.Serializer):
    # Ejercicio 10

    def validate(self, data):
        # Ejercicio 11
        pass