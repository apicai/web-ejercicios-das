from rest_framework.exceptions import ValidationError
from django.test import SimpleTestCase, TestCase
from api.users import serializers

class TestUsuarioSerializer(SimpleTestCase):
    # Ejercicio 21
    pass



class TestRegistroView(TestCase):
    # Ejercicio 22
    pass
