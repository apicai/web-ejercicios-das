from django.db import models
from django.contrib.auth.models import AbstractUser

class Usuario(AbstractUser):
    # Ejercicio 2

    def save(self, *args, **kwargs):
        if not self.username:
            self.username = self.email
        super().save(*args, **kwargs)
